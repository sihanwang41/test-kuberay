from ray import serve
import time

@serve.deployment
class MyModel:
    def __init__(self):
        time.sleep(5)

    def __call__(self):
        return "123"

model = MyModel.bind()
